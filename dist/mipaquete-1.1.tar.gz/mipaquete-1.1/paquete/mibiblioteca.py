def potencia(base, exponente=2):
    return base**exponente

def sumar(termino1, termino2):
    return termino1+termino2


pi_cuadrado = 3.14**2


