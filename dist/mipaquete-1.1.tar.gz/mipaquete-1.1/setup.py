from setuptools import setup

setup(
    name="mipaquete",
    version="1.1",
    description="Paquete de funciones y variables matematicas",
    author="Alejandro Fernandez",
    author_email="alef@hotmail.com",
    packages=["paquete"]



)